$(document).ready(function(){
$(,.switch').click(function(){
$(,.menu').toggleClass(,visible');
});
});